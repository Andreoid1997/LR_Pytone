from librip.ex4 import print_result


# Необходимо верно реализовать print_result
# и задание будет выполнено

@print_result  # test_1=print_result(test_1)
def test_1():
    return 1


@print_result
def test_2():
    return 'iu'


@print_result
def test_3():
    return {'a': 1, 'b': 2}


@print_result
def test_4():
    return [1, 2]


test_1()
test_2()
test_3()
test_4()