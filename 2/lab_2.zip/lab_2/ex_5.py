import time
from librip.ex5 import timer

with timer():
    time.sleep(0.5)
